package com.example.yiuyiuyoyoho_comp304sec003_lab02.views

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import com.example.yiuyiuyoyoho_comp304sec003_lab02.navigation.Activities

object TasksUIState {
    //var isTaskCreated: MutableState<Activities> = mutableStateOf(Activities.HomeActivity)
}